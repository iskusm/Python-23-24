for t in range(1, 13):
    print(f'{t:2}{t**2:5}{t**3:6}')