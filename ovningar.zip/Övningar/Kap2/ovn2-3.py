f = float(input('Temperatur i Fahrenheit? '))
c = (f - 32) * 5 / 9
print(f'Motsvarar {c:.1f} grader')