import math
r = float(input('Radie? '))
v = 4 * math.pi * r**3 / 3
a = 4 * math.pi * r**2
print(f'Volym: {v:.3f}')
print(f'Area:  {a:.3f}')