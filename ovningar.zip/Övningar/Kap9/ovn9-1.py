# Modulen area (Filen ska egentligen heta area.py)
import math

def rektangel(b , h):
    return b * h

def cirkel(r):
    return math.pi * r ** 2

def triangel(b, h):
    return b * h / 2