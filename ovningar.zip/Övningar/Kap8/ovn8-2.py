def tab(n):
    for i in range(1, 11):
        print(f'{i:2}{i*n:5}')

# Test
tab(6)