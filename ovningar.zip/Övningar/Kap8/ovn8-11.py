la = input('Skriv ett antal ord: ').split()
lb = sorted(la, key=len)
print(lb)