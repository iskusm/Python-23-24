s = input('Skriv en text: ')
s = s.replace(' ', '')
print(s)