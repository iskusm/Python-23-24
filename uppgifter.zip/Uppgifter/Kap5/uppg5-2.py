txt = input('Skriv en text: ')
if txt[0] == txt[len(txt)-1]:
    print('Lika')
else:
    print('Inte lika')