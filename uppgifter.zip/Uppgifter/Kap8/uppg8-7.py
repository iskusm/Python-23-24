def medelv(a):
    return sum(a)/len(a)

l = [1, 2, 3, 2, 1]
t = (1, 2, 3, 2, 1)
print(medelv(l))
print(medelv(t))