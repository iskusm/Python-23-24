def ref_demo(a, x):
    l = [e for e in a if e >= x]
    return sum(l)
