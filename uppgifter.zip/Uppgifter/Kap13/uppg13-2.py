class Bil:
    def __init__(self):
        self.reg_nr = ''
        self.fabrikat = ''
        self.årsmodell = 0
        self.tjänstevikt = 0.0
        self.effekt = 0.0

b1 = Bil()
b2 = Bil()