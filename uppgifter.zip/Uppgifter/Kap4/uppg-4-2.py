n = int(input('Talet n? '))
sum = 0
i=1
while i <= n:
    sum = sum + i*i
    i= i + 1
print('Summan =', sum)