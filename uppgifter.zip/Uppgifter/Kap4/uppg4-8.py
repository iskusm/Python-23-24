for v in range(-10,11):
  x = v / 10
  y = 2 * x**2 - 5 * x + 1
  print(f"{x:1.1f}{y:7.2f}")