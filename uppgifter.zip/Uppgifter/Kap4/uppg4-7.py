for x in range(-10, 11):
  y = 2 * x**2 - 5 * x + 1
  print(f"{x:3d}{y:6d}")