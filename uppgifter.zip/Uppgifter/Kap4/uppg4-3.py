n = int(input('Talet n? '))
sum = 0
i=1
while i <= n:
    sum = sum + 1 / i
    i= i + 1
print('Summan =', sum)