import random
print('Tärningarna är kastade')
n1 = random.randint(1,6)
n2 = random.randint(1,6)
print('Summa:', n1+n2)