svar = input('Skriv ett tal: ')
x = float(svar)
y = x * x
print('Talet i kvadrat är', y)