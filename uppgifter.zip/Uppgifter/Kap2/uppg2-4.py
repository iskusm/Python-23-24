svar = input('Kvadratens sida: ')
x = float(svar)
omkr = 4 * x
area = x * x
print('Omkrets:', omkr)
print('Area:', area)