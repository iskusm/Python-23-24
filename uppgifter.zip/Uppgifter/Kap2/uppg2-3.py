svar = input('Skriv ett tal: ')
x = float(svar)
y = x * x
print(f'Talet i kvadrat: {y:8.2f}')