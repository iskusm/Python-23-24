svar = input('Skriv ett tal: ')
x = float(svar)
y = x * x
print(f'Talet i kvadrat är {y:.2f}')