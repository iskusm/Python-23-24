import math
a = float(input('Första sidan? '))
b = float(input('Andra sidan?  '))
c = math.sqrt(a**2 + b**2)
print(f'Hypotenusans längd: {c:.2f}')