# Ett program som simulerar ett tärningskast
import random
print('Tärningen är kastad')
n = random.randint(1,6)     # ett slumtal mellan 1 och 6
print('Du fick', n)