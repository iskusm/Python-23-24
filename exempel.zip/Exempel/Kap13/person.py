class Person:
    def __init__(self):
        self.förnamn = ''
        self.efternamn = ''
        self.född_år = ''
        self.singel = True