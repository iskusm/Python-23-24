class Konto:
    def __init__(self):
        self.kontohavare = None
        self.saldo = 0
        self.intjänad_ränta = 0