print('[', end='')
k = 0
while k < 6:
    print(f'{k:2}', end='')
    k = k + 2
print(' ]')