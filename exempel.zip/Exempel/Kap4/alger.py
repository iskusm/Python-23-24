# Utbredning av alger
totalArea = 10000
area = 0.01
dygn = 1
while area  < totalArea:
    area = area * 2
    dygn = dygn + 1
print(f'Sjön blir täckt efter {dygn} dygn')